function solveSudoku(algo, board, depthLimit) {
  let queue;
  let stack;
  // Data types for all algorithms
  switch (algo) {
    case "BFS":
      queue = [board];
      break;
    case "DFS":
    case "IDS":
      stack = [[board, 0]];
      break;
    case "Greedy":
      stack = [board];
      break;
    default:
      throw new Error("Invalid algorithm specified");
  }
  let delay = 10; // Adjust the delay time (in milliseconds) as needed

  function solve(currentBoard, depth = 0) {
    let emptyCell = findEmptyCell(currentBoard);

    if (!emptyCell) {
      // Puzzle solved successfully
      updateBoard(currentBoard, true);
      return currentBoard;
    }

    if (algo === "BFS" && queue.length === 0) {
      return null; // No solution found (BFS specific)
    } else if (depth >= depthLimit && algo === "IDS") {
      return null; // No solution within depth limit (IDS specific)
    }

    let [row, col] = emptyCell;

    if (algo === "Greedy") {
      let nextCell = findNextCellGreedy(currentBoard);
      row = nextCell[0];
      col = nextCell[1];
    }

    for (let num = 1; num <= board.length; num++) {
      if (isValidMove(currentBoard, row, col, num)) {
        let newBoard = copyBoard(currentBoard);
        newBoard[row][col] = num;
        if (algo === "BFS") {
          queue.push(newBoard);
        } else if (algo === "Greedy") {
          stack.push(newBoard);
        } else {
          stack.push([newBoard, depth + 1]); // Update depth for DFS/IDS
        }
      }
    }

    let nextBoard;
    switch (algo) {
      case "BFS":
        nextBoard = queue.shift();
        break;
      case "DFS":
      case "IDS":
      case "Greedy":
        nextBoard = stack.pop();
        break;
      default:
        throw new Error("Invalid algorithm specified");
    }

    updateBoard(currentBoard, true); // Can be called before or after pushing to stack

    if (algo === "BFS" || algo === "Greedy") {
      return setTimeout(() => solve(nextBoard), delay); // Recursive call with next state and depth for BFS/Greedy
    } else {
      return setTimeout(() => solve(nextBoard[0], nextBoard[1]), delay); // Recursive call with next state and depth for DFS/IDS
    }
  }

  // Start the recursive step with a delay
  return setTimeout(() => solve(board), delay);
}

// Implement findNextCellGreedy function here

function findNextCellGreedy(board) {
  // This function should find the empty cell with the fewest possible valid moves.
  // Here's an example implementation:
  let minValidMoves = board.length;
  let minValidCell = null;

  for (let row = 0; row < board.length; row++) {
    for (let col = 0; col < board.length; col++) {
      if (board[row][col] === 0) {
        let validMoves = 0;
        for (let num = 1; num <= board.length; num++) {
          if (isValidMove(board, row, col, num)) {
            validMoves++;
          }
        }
        if (validMoves < minValidMoves) {
          minValidMoves = validMoves;
          minValidCell = [row, col];
        }
      }
    }
  }

  return minValidCell; // Return the cell with the fewest valid moves
}
