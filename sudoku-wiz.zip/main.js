// Function to check if a move is valid in Sudoku
function isValidMove(board, row, col, num) {
  const boardLength = board.length;
  const subgridSize = Math.sqrt(boardLength);
  // Check row and column for duplicates (early return)
  for (let i = 0; i < boardLength; i++) {
    if (
      (board[row][i] === num && i !== col) ||
      (board[i][col] === num && i !== row)
    ) {
      return false;
    }
  }

  // Calculate the starting indices of the subgrid containing (row, col)
  const startRow = Math.floor(row / subgridSize) * subgridSize;
  const startCol = Math.floor(col / subgridSize) * subgridSize;

  // Check for conflicts in the subgrid
  for (let i = startRow; i < startRow + subgridSize; i++) {
    for (let j = startCol; j < startCol + subgridSize; j++) {
      if (board[i][j] === num && (i !== row || j !== col)) {
        return false;
      }
    }
  }

  return true;
}

// Function to find repeated number of a row or column
function findRepeatedNumber(board, row, col, num) {
  const boardLength = board.length;
  const repeatedNumbers = []; // Store all repeated numbers

  // Check row for duplicates
  for (let i = 0; i < boardLength; i++) {
    if (board[row][i] === num && i !== col) {
      repeatedNumbers.push({ number: board[row][i], cellId: `cell${row}${i}` });
    }
  }

  // Check column for duplicates (separate loop)
  for (let i = 0; i < boardLength; i++) {
    if (board[i][col] === num && i !== row) {
      repeatedNumbers.push({ number: board[i][col], cellId: `cell${i}${col}` });
    }
  }

  const subgridSize = Math.sqrt(boardLength);
  const startRow = Math.floor(row / subgridSize) * subgridSize;
  const startCol = Math.floor(col / subgridSize) * subgridSize;

  // Check for conflicts in the subgrid
  for (let i = startRow; i < startRow + subgridSize; i++) {
    for (let j = startCol; j < startCol + subgridSize; j++) {
      if (board[i][j] === num && (i !== row || j !== col)) {
        repeatedNumbers.push({ number: board[i][j], cellId: `cell${i}${j}` });
      }
    }
  }

  return repeatedNumbers.length > 0 ? repeatedNumbers : null; // Return array or null
}

// Function to validate the entire Sudoku board
function validateSolution(board) {
  const boardLength = board.length;
  // Check each row, column, and 3x3 subgrid
  for (let i = 0; i < boardLength; i++) {
    for (let j = 0; j < boardLength; j++) {
      const num = board[i][j];
      if (num !== 0 && !isValidMove(board, i, j, num)) {
        return false; // Invalid move found
      }
    }
  }
  return true; // Solution is valid
}

// Function to render Sudoku board on the UI
function renderBoard(board) {
  const boardLength = board.length;
  const sudokuBoard = document.getElementById("sudokuBoard");
  sudokuBoard.innerHTML = ""; // Clear previous board

  for (let row = 0; row < boardLength; row++) {
    const rowDiv = document.createElement("div");
    rowDiv.classList.add("row");

    for (let col = 0; col < boardLength; col++) {
      const cellInput = document.createElement("input");
      cellInput.setAttribute("type", "text");
      cellInput.setAttribute("autocomplete", "off");
      cellInput.setAttribute("id", "cell" + row + col);
      cellInput.classList.add("cell");
      cellInput.setAttribute("maxlength", "1"); // Only one number is entered
      if (board[row][col] === 0) {
        cellInput.style.backgroundColor = "#fff";
      } else {
        cellInput.style.backgroundColor = "#ccc";
      }

      // Convert array zeros to blank cells and disable preexisting board numbers
      if (board[row][col] === 0) {
        cellInput.value = "";
      } else {
        cellInput.value = board[row][col];
        cellInput.setAttribute("disabled", true);
      }

      cellInput.addEventListener("input", handleUserInput);
      // Switch numbers when user presses on another number immediately.
      document.querySelectorAll("input").forEach(function (input) {
        input.addEventListener("keydown", function (event) {
          // Check if the pressed key is not an arrow key
          if (
            ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].indexOf(
              event.key
            ) === -1
          ) {
            this.value = ""; // Clear the input value
          }
        });
      });

      rowDiv.appendChild(cellInput);
    }

    sudokuBoard.append(rowDiv);
  }
}

document.addEventListener("DOMContentLoaded", () => {
  const cells = document.querySelectorAll(".cell");
  let focusedIndex = 0;

  function handleArrowKeys(event) {
    let nextIndex;
    const boardLength = board.length; // Cache board length for efficiency

    if (event.key === "ArrowUp") {
      const row = Math.floor(focusedIndex / boardLength);
      nextIndex =
        row === 0
          ? focusedIndex + (boardLength - 1)
          : focusedIndex - boardLength;
    } else if (event.key === "ArrowDown") {
      const row = Math.floor(focusedIndex / boardLength);
      nextIndex =
        row === boardLength - 1
          ? focusedIndex - (boardLength - 1)
          : focusedIndex + boardLength;
    } else if (event.key === "ArrowLeft") {
      nextIndex = Math.max(0, focusedIndex - 1);
    } else if (event.key === "ArrowRight") {
      nextIndex = Math.min(cells.length - 1, focusedIndex + 1);
    } else {
      return; // Ignore other keys
    }

    const nextCell = cells[nextIndex];
    if (nextCell && nextCell.hasAttribute("disabled")) {
      // If the next cell is disabled, recursively call handleArrowKeys
      focusedIndex = nextIndex;
      handleArrowKeys(event);
    } else if (nextCell) {
      // Otherwise, focus the next cell
      nextCell.focus();
      focusedIndex = nextIndex;
    }
  }

  cells.forEach((cell) => {
    cell.addEventListener("keydown", handleArrowKeys); // Existing keydown listener
  });
});
function handleUserInput(event) {
  const cellInput = event.target;
  const cellId = cellInput.id;
  const row = parseInt(cellId.charAt(4));
  const col = parseInt(cellId.charAt(5));
  update(cellInput, board, row, col);
  lastSelectedMouseIndex = row * board.length + col;
}

function updateBoard(board, isAIUpdate = true) {
  for (let row = 0; row < board.length; row++) {
    for (let col = 0; col < board.length; col++) {
      const cellInput = document.getElementById("cell" + row + col);
      update(cellInput, board, row, col, isAIUpdate); // Pass cellInput and other arguments
    }
  }
}

function update(cellInput, board, row, col, isAIUpdate = false) {
  const value = parseInt(cellInput.value) || 0;
  // Regex for input validation (1-9)
  const numOnly = /^[1-9]$/;
  if (!numOnly.test(cellInput.value)) cellInput.value = "";
  // Convert array zeros to blank cells and disable preexisting board numbers
  if (isAIUpdate) {
    if (board[row][col] === 0) {
      cellInput.value = "";
    } else {
      // Insert values in AI update event
      cellInput.value = board[row][col];
      cellInput.setAttribute("disabled", true);
    }
  } else {
    // Insert values in user input event
    board[row][col] = value;
  }
  const repeatedNumbers = findRepeatedNumber(board, row, col, value);

  // Update class for all other repeated numbers (if any)
  if (repeatedNumbers) {
    document.querySelectorAll(".cell").forEach((otherCell) => {
      const otherCellId = otherCell.id;
      const isRepeated = repeatedNumbers.some(
        (repeatedNumber) => repeatedNumber.cellId === otherCellId
      );

      if (otherCell !== cellInput && isRepeated) {
        otherCell.classList.add("repeated-number"); // Add class for repeated numbers
      } else {
        otherCell.classList.remove("repeated-number"); // Remove class if not repeated
      }
    });
  }
  // Handle repeated number classes
  cellInput.classList.toggle("repeated-number", !!repeatedNumbers); // Toggle class on selected cell
  if (!isValidMove(board, row, col, value)) {
    cellInput.classList.add("invalid");
  } else {
    cellInput.classList.remove("invalid");
  }
}

// Function to find an empty cell in the Sudoku board
function findEmptyCell(board) {
  for (let row = 0; row < board.length; row++) {
    for (let col = 0; col < board.length; col++) {
      if (board[row][col] === 0) {
        return [row, col];
      }
    }
  }
  return null; // No empty cell found
}

function findAllEmptyCells(board) {
  const emptyCells = [];

  for (let row = 0; row < board.length; row++) {
    for (let col = 0; col < board.length; col++) {
      if (board[row][col] === 0) {
        emptyCells.push([row, col]);
      }
    }
  }

  return emptyCells;
}

// Function to copy a Sudoku board
function copyBoard(board) {
  return board.map((row) => row.slice());
}
// Example Sudoku board
const board = [
  [5, 3, 0, 0, 7, 0, 0, 0, 0],
  [6, 0, 0, 1, 9, 5, 0, 0, 0],
  [0, 9, 8, 0, 0, 0, 0, 6, 0],
  [8, 0, 0, 0, 6, 0, 0, 0, 3],
  [4, 0, 0, 8, 0, 3, 0, 0, 1],
  [7, 0, 0, 0, 2, 0, 0, 0, 6],
  [0, 6, 0, 0, 0, 0, 2, 8, 0],
  [0, 0, 0, 4, 1, 9, 0, 0, 5],
  [0, 0, 0, 0, 8, 0, 0, 7, 9],
];

renderBoard(board); // Initial rendering of Sudoku board

const btnBFS = document.getElementById("btnBFS");
btnBFS.addEventListener("click", () => {
  const solvedBoard = solveSudoku("BFS", board);
  updateBoard(solvedBoard, true);
});

const btnDFS = document.getElementById("btnDFS");
btnDFS.addEventListener("click", () => {
  const solvedBoard = solveSudoku("DFS", board);
  updateBoard(solvedBoard, true);
});

const btnDLS = document.getElementById("btnIDS");
btnDLS.addEventListener("click", () => {
  const solvedBoard = solveSudoku("IDS", board);
  updateBoard(solvedBoard, true);
});

const btnGreedy = document.getElementById("btnGreedy");
btnGreedy.addEventListener("click", () => {
  const solvedBoard = solveSudoku("Greedy", board);
  updateBoard(solvedBoard, true);
});
